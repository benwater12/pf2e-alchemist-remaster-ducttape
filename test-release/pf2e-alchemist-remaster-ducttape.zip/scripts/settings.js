import { LT } from "./localization.js";
console.log("%cPF2e Alchemist Remaster Duct Tape | settings.js loaded","color: aqua; font-weight: bold;");

/* ==========================================================================
	Globals
========================================================================== */

// Compendium folder migration
const ARDT_MODULE_ID = "pf2e-alchemist-remaster-ducttape";
const ARDT_COMP_FOLDER_NAME = "PF2e Alchemist Duct Tape";
// Keep this in sync with module.json "packs"[].name
const ARDT_PACK_NAMES = [
	"alchemist-duct-tape-macros",
	"alchemist-duct-tape-items",
	"alchemist-duct-tape-journal"
];
const ARDT_FLAGS_SETTING = "ardtFlags";	// single object: { folderMigration: true, ... }

/* ==========================================================================
	Exported functions
========================================================================== */

	// console logger gated by the module debug level; level 1 info, 2 warn, 3 error
	export function debugLog(intLogType, stringLogMsg, objObject = null) {
		
		// Get Timestamps
		const now = new Date();
		const timestamp = now.toTimeString().split(' ')[0]; // "HH:MM:SS"
		
		// Handle the case where the first argument is a string
		if (typeof intLogType === "string") {
			objObject = stringLogMsg; // Shift arguments
			stringLogMsg = intLogType;
			intLogType = 1; // Default log type to 'all'
		}
		const debugLevel = game.settings.get("pf2e-alchemist-remaster-ducttape", "debugLevel");

		// Map debugLevel setting to numeric value for comparison
		const levelMap = {
			"none": 4,
			"error": 3,
			"warn": 2,
			"all": 1
		};

		const currentLevel = levelMap[debugLevel] || 4; // Default to 'none' if debugLevel is undefined

		// Check if the log type should be logged based on the current debug level
		if (intLogType < currentLevel) return;

		// Capture stack trace to get file and line number
		const stack = new Error().stack.split("\n");
		let fileInfo = "";
		for (let i = 2; i < stack.length; i++) {
			const line = stack[i].trim();
			const fileInfoMatch = line.match(/(\/[^)]+):(\d+):(\d+)/); // Match file path and line number
			if (fileInfoMatch) {
				const [, filePath, lineNumber] = fileInfoMatch;
				const fileName = filePath.split("/").pop(); // Extract just the file name
				// Ensure the file is one of the allowed files
				const allowedFiles = [
					"AlchemistFeats.js",
					"AlchIndex.js",
					"FormulaSearch.js",
					"HealingBomb.js",
					"LevelUp.js",
					"localization.js",
					"QAEffects.js",
					"QuickAlchemy.js",
					"settings.js",
					"VialSearch.js"
				];
				if (allowedFiles.includes(fileName)) {
					fileInfo = `[${fileName}:${lineNumber}]`;
					break;
				}
			}
		}

		// Prepend the file and line info to the log message
		const formattedLogMsg = `${fileInfo} ${stringLogMsg}`;
		
		if (objObject) {
			switch (intLogType) {
				case 1: // Info/Log (all)
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | ${formattedLogMsg}`, "color: aqua; font-weight: bold;", objObject);
					break;
				case 2: // Warning
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | WARNING: ${formattedLogMsg}`, "color: orange; font-weight: bold;", objObject);
					break;
				case 3: // Critical/Error
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | ERROR: ${formattedLogMsg}`, "color: red; font-weight: bold;", objObject);
					break;
				default:
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | ${formattedLogMsg}`, "color: aqua; font-weight: bold;", objObject);
			}
		} else {
			switch (intLogType) {
				case 1: // Info/Log (all)
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | ${formattedLogMsg}`, "color: aqua; font-weight: bold;");
					break;
				case 2: // Warning
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | WARNING: ${formattedLogMsg}`, "color: orange; font-weight: bold;");
					break;
				case 3: // Critical/Error
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | ERROR: ${formattedLogMsg}`, "color: red; font-weight: bold;");
					break;
				default:
					console.log(`%cPF2e Alchemist Remaster Duct Tape [${timestamp}] | ${formattedLogMsg}`, "color: aqua; font-weight: bold;");
			}
		}
	}

	// get a module setting by name; returnIfError is used on any failure. This module's settings only.
	export function getSetting(settingName, returnIfError = false) {
		// Validate the setting name
		if (typeof settingName !== "string" || settingName.trim() === "") {
			debugLog(3, `Invalid setting name provided: ${settingName}`);
			return returnIfError; // Return undefined or a default value
		}

		// Check if the setting is registered
		if (!game.settings.settings.has(`pf2e-alchemist-remaster-ducttape.${settingName}`)) {
			debugLog(3, `Setting "${settingName}" is not registered.`);
			return returnIfError; // Return undefined or a default value
		}

		try {
			// Attempt to retrieve the setting value
			const value = game.settings.get("pf2e-alchemist-remaster-ducttape", settingName);
			//debugLog(1, `Successfully retrieved setting "${settingName}":`, value);
			return value;
		} catch (error) {
			// Log the error and return undefined or a default value
			debugLog(3, `Failed to get setting "${settingName}":`, error);
			return returnIfError;
		}
	}

	//	Check if actor has a feat by searching for the slug, example "powerful-alchemy"
	export function hasFeat(actor, slug) {
		return actor.itemTypes.feat.some((feat) => feat.slug === slug);
	}

	//	Checks if a character qualifies for Quick Alchemy, and how.
	export function qualifiesForQA(actor) {
		if (!actor) return { qualifies: false, dc: 0, isArchetype: false, canQuickVial: false, canCraftWeapons: false, explorationVials: false, vialDamageType: "acid", log: `no valid actor passed` };

		// Check if the actor's class matches the localized Alchemist class name
		const isAlchemistClass = actor?.class?.system?.slug === 'alchemist';

		// Check if the actor has the localized Alchemist Dedication feat
		const hasAlchemistDedication = hasFeat(actor, "alchemist-dedication");

		// Archetypes that grant the quick alchemy benefits without a true research field.
		// Munitions Machinist (Gunslinger) makes bombs/alchemical ammunition; Firework Technician
		// makes pyrotechnic vials/fireworks. Neither uses the acid/poison research-field Quick Vial.
		const hasMunitionsMachinist = hasFeat(actor, "munitions-machinist");
		const hasFireworkTechnician = hasFeat(actor, "firework-technician-dedication");

		const qaLog = `${actor.name} is Alchemist: ${isAlchemistClass} | Alchemist Dedication: ${hasAlchemistDedication} | Munitions Machinist: ${hasMunitionsMachinist} | Firework Technician: ${hasFireworkTechnician}`;

		// These archetypes grant Quick Alchemy but not the acid/poison research-field Quick Vial
		const archetypeNoResearchVial = (hasMunitionsMachinist || hasFireworkTechnician)
			&& !isAlchemistClass && !hasAlchemistDedication;

		// Who replenishes versatile vials during exploration: the Alchemist class and
		// Firework Technician (explicit in its dedication). Plain dedication and Munitions
		// Machinist only make vials during daily prep, so they are excluded.
		const explorationVials = isAlchemistClass || hasFireworkTechnician;

		// Firework Technician's pyrotechnic versatile vials are fire; everyone else's are acid.
		const vialDamageType = (hasFireworkTechnician && !isAlchemistClass) ? "fire" : "acid";

		// Firework Technician's Quick Alchemy makes only fireworks consumables/ammo (black powder,
		// sparkler, etc.), not bombs, so a firework-only actor gets no Weapon tab. Everyone else can.
		const fireworkOnly = hasFireworkTechnician
			&& !isAlchemistClass && !hasAlchemistDedication && !hasMunitionsMachinist;
		const canCraftWeapons = !fireworkOnly;

		// If the actor qualifies, get the Alchemist Class DC
		if (isAlchemistClass || hasAlchemistDedication || hasMunitionsMachinist || hasFireworkTechnician) {
			const alchemistClassDC = actor.system.proficiencies.classDCs.alchemist?.dc || 0;
			return {
				qualifies: true,
				dc: alchemistClassDC,
				isArchetype: !isAlchemistClass,
				canQuickVial: !archetypeNoResearchVial,
				canCraftWeapons,
				explorationVials,
				vialDamageType,
				log: qaLog
			};
		}
		// If the actor doesn't qualify
		return { qualifies: false, dc: 0, isArchetype: false, canQuickVial: false, canCraftWeapons: false, explorationVials: false, vialDamageType: "acid", log: qaLog };
	}

	// true if the actor has a non-GM owner currently logged in
	export function hasActiveOwners(actor) {
		// Get owners with ownership level 3 ('Owner')
		const owners = Object.keys(actor.ownership).filter(userId => actor.ownership[userId] === 3);

		// Filter for logged-in owners who are not GMs
		const loggedInOwners = game.users.contents.filter(user => owners.includes(user.id) && user.active && !user.isGM);

		// Debug output
		debugLog(`Owners for ${actor.name}: ${owners.join(', ')}, Logged-in owners (non-GM): ${loggedInOwners.map(u => u.name).join(', ')}`);

		// Return whether any non-GM logged-in owners exist
		return loggedInOwners.length > 0;
	}

/* ==========================================================================
	Internal functions and helpers
========================================================================== */

	// defer chat-collapse to xdy-pf2e-workbench when it is managing collapsibility
	function adjustCollapseSettingBasedOnWorkbench() {
		if (!game.user.isGM) return;
		const settingKey = "pf2e-alchemist-remaster-ducttape.collapseChatDesc";
		const workbenchSettingKey = "xdy-pf2e-workbench.autoCollapseItemChatCardContent";
		const isWorkbenchInstalled = game.modules.get("xdy-pf2e-workbench")?.active;

		if (!isWorkbenchInstalled) return; // Not installed - exit early
		
		if (!game.settings.settings.has(workbenchSettingKey)) {// settings key not found
			console.log(LT.settingWorkbenchNotFound());
			return;
		}
		const currentWorkbenchSetting = game.settings.get("xdy-pf2e-workbench", "autoCollapseItemChatCardContent");

		// Check if the collapseChatDesc setting exists
		if (!game.settings.settings.has(settingKey)) return;

		// If Workbench is managing collapsibility, set collapseChatDesc to false
		if (currentWorkbenchSetting === "collapsedDefault" || currentWorkbenchSetting === "nonCollapsedDefault") {
			if (game.settings.get("pf2e-alchemist-remaster-ducttape", "collapseChatDesc") === true) {
				game.settings.set("pf2e-alchemist-remaster-ducttape", "collapseChatDesc", false);
				console.log("PF2e Alchemist Remaster Duct Tape | xdy-pf2e-workbench is managing collapsibility.");
			}
		}
	}

	//	AddCompendiumsApp class object
	window.AddCompendiumsApp = class AddCompendiumsApp extends FormApplication {
    static get defaultOptions() {
        return foundry.utils.mergeObject(super.defaultOptions, {
            title: LT.settingManageHomebrewCompendium(),
            template: 'modules/pf2e-alchemist-remaster-ducttape/templates/add-compendiums.html',
            width: 600,
            height: 'auto',
            closeOnSubmit: false
        });
    }

    getData() {
        const savedCompendiums = game.settings.get('pf2e-alchemist-remaster-ducttape', 'compendiums') || [];
        return {
            savedCompendiums,
            tempCompendiums: this.tempCompendiums || []
        };
    }

    activateListeners(html) {
        super.activateListeners(html);

        // Add a compendium to the temporary list
        html.find('#add-compendium-btn').click(() => {
            const input = html.find('#compendium-input').val().trim();
            if (!input) return;

            const pack = game.packs.get(input);
            if (this.tempCompendiums?.some(comp => comp.name === input)) {
                ui.notifications.warn(LT.settingCompendiumAlreadyInList({ input }));
                return;
            }

            if (!pack || pack.documentName !== 'Item') {
                ui.notifications.error(LT.settingCompendiumInvalid({ input }));
                return;
            }
            this.tempCompendiums = [...(this.tempCompendiums || []), { name: input, valid: !!pack }];
            this.render();
        });

        // Remove a compendium from the temporary list
        html.find('.delete-compendium').click((event) => {
            const index = parseInt(event.currentTarget.dataset.index);
            this.tempCompendiums.splice(index, 1);
            this.render();
        });

        // Remove a saved compendium
        html.find('.delete-saved-compendium').click(async (event) => {
            const compendiumToDelete = event.currentTarget.dataset.name;
            const savedCompendiums = game.settings.get('pf2e-alchemist-remaster-ducttape', 'compendiums') || [];
            const updatedCompendiums = savedCompendiums.filter(c => c !== compendiumToDelete);

            await game.settings.set('pf2e-alchemist-remaster-ducttape', 'compendiums', updatedCompendiums);
            ui.notifications.info(LT.settingCompendiumRemoved({ compendium: compendiumToDelete }));
            this.render();
        });

        // Save compendiums when the Save button is clicked
        html.find('#save-compendiums-btn').click(async () => {
            const savedCompendiums = game.settings.get('pf2e-alchemist-remaster-ducttape', 'compendiums') || [];
            const uniqueCompendiums = new Map(); // Use Map to avoid duplicates

            let invalidEntries = [];
            for (const { name, valid } of this.tempCompendiums || []) {
                if (valid) uniqueCompendiums.set(name, true);
                else invalidEntries.push(name);
            }

            if (invalidEntries.length > 0) {
                new Dialog({
                    title: 'Invalid or Duplicate Entries',
                    content: `${LT.settingCompendiumListInvalid()}<br>${invalidEntries.join('<br>')}`,
                    buttons: {
                        ok: {
                            icon: '<i class="fas fa-check"></i>',
                            label: LT.ok()
                        }
                    }
                }).render(true);
            }

            // Save valid entries
            await game.settings.set(
                'pf2e-alchemist-remaster-ducttape',
                'compendiums',
                [...new Set([...savedCompendiums, ...uniqueCompendiums.keys()])]
            );
            ui.notifications.info(LT.settingSaved());
            this.tempCompendiums = [];
            this.close();
        });
    }

    async _updateObject(event, formData) {
        // No action needed since save is handled manually
    }
	};

	// Get the full migrations object (always returns an object).
	function getMigrations() {
		const obj = game.settings.get(ARDT_MODULE_ID, ARDT_FLAGS_SETTING);
		return obj && typeof obj === "object" ? { ...obj } : {};
	}

	// Set/merge a single flag without clobbering others.
	async function setMigrationFlag(key, value) {
		const current = getMigrations();
		current[key] = value;
		await game.settings.set(ARDT_MODULE_ID, ARDT_FLAGS_SETTING, current);
	}

	/** Check a flag; falsy if missing. */
	function hasMigrationFlag(key) {
		const current = getMigrations();
		return Boolean(current[key]);
	}

	// Check folder migration 
	async function checkFolderMigration(){
		if (!game.user.isGM) return; // GM only
		if (hasMigrationFlag("folderMigration")) return; // we already migrated

		try {
			let folder = game.folders.find((f) => f.type === "Compendium" && f.name === ARDT_COMP_FOLDER_NAME);
			// If folder doesn't exist create it
			if (!folder) { 
				folder = await Folder.create({ name: ARDT_COMP_FOLDER_NAME, type: "Compendium", sorting: "a" });
				debugLog("settings.js | Created compendium folder:", ARDT_COMP_FOLDER_NAME, folder?.id);
			}

			// move packs into folder
			const movedPacks = [], missingPacks = [];
			for (const name of ARDT_PACK_NAMES) {
				const cid = `${ARDT_MODULE_ID}.${name}`;
				const pack = game.packs.get(cid);
				if (!pack) { missingPacks.push(cid); continue; }
				await pack.configure({ folder: folder.id });
				movedPacks.push(cid);
			}

			// update flag
			await setMigrationFlag("folderMigration", true);
			ui.compendium.render(true);
			debugLog("settings.js | Compendium folder migration complete.", { movedPacks, missingPacks });
		} catch (err) {
			debugLog(3, "settings.js | Compendium folder migration failed:", err?.message ?? err);
		}
	}


/* ==========================================================================
	Settings section headers
========================================================================== */

	const ARDT_SETTINGS_SECTIONS = [
		{ before: "showFormulaDescription",  label: "Quick Alchemy" },
		{ before: "enablePowerfulAlchemy",   label: "Powerful Alchemy" },
		{ before: "healingBombPC2Errata",    label: "Healing Bomb" },
		{ before: "addFormulasOnLevelUp",    label: "Level Up" },
		{ before: "vialSearchReminder",      label: "Vial Search" },
		{ before: "searchableFormulas",      label: "Display" },
		{ before: "debugLevel",              label: "Module" },
	];

	function injectSettingsSectionHeaders(html) {
		const section = html.querySelector('[data-tab="pf2e-alchemist-remaster-ducttape"][data-category="pf2e-alchemist-remaster-ducttape"]');
		if (!section) return;
		for (const { before, label } of ARDT_SETTINGS_SECTIONS) {
			const key = `pf2e-alchemist-remaster-ducttape.${before}`;
			const input = section.querySelector(`[data-setting-id="${key}"], input[name="${key}"], select[name="${key}"]`);
			if (!input) continue;
			const group = input.closest(".form-group");
			if (!group) continue;
			if (group.previousElementSibling?.classList?.contains("ardt-settings-header")) continue;
			const h3 = document.createElement("h3");
			h3.className = "ardt-settings-header";
			h3.textContent = label;
			group.before(h3);
		}
	}

/* ==========================================================================
	Hooks
========================================================================== */

	Hooks.once("init", () => {

	//	=== Saved Data Settings ===

		// Alchemical Index blob (uuid -> { name, desc, updatedAt })
		game.settings.register("pf2e-alchemist-remaster-ducttape", "alchIndex", {
			scope: "world",
			config: false,
			type: Object,
			default: { items: {}, meta: {} },
		});

		// Metadata we compare against to know when to prompt
		game.settings.register("pf2e-alchemist-remaster-ducttape", "alchIndexMeta", {
			scope: "world",
			config: false,
			type: Object,
			default: { systemVersion: "", locale: "", lastBuilt: 0, itemCount: 0 },
		});

		// Tracks the last processed time for exploration mode
		game.settings.register('pf2e-alchemist-remaster-ducttape', 'explorationTime', {
			name: 'Last Processed Time',
			scope: 'world',
			config: false,
			type: Number,
			default: 0
		});
		// Tracks the last recorded world time to calculate elapsed time
		game.settings.register('pf2e-alchemist-remaster-ducttape', 'previousTime', {
			name: 'Previous World Time',
			scope: 'world',
			config: false,
			type: Number,
			default: 0
		});

		// Setting to hold module flags
		game.settings.register(ARDT_MODULE_ID, ARDT_FLAGS_SETTING, {
			scope: "world",
			config: false,
			type: Object,
			default: {}	
		});
		
	//	QUICK ALCHEMY SETTINGS

		// Show description in QA dialog
		game.settings.register("pf2e-alchemist-remaster-ducttape", "showFormulaDescription", {
			name: LT.settingShowFormulaDescName(),
			hint: LT.settingShowFormulaDescHint(),
			scope: "client",
			config: true,
			type: Boolean,
			default: true,
			requiresReload: false,
			onChange: (value) => {
				console.log(`Setting changed: showFormulaDescription=${value}`);
			}
		});
		// Quick Alchemy: remove temporary items at end of turn
		game.settings.register("pf2e-alchemist-remaster-ducttape", "removeTempItemsAtTurnChange", {
			name: LT.settingRemoveTempStartTurn(),
			scope: "world",
			config: true,
			default: true,
			type: Boolean,
			requiresReload: false,
		});
		
		// Quick Alchemy: remove temporary items at end of combat
		game.settings.register("pf2e-alchemist-remaster-ducttape", "removeTempItemsAtEndCombat", {
			name: LT.settingRemoveTempEndCombat(),
			scope: "world",
			config: true,
			default: true,
			type: Boolean,
			requiresReload: false,
		});
		
		// Quick Alchemy: Send chat message when removing temp quick alchemy items
		game.settings.register("pf2e-alchemist-remaster-ducttape", "createRemovedTempItemsMsg", {
			name: LT.settingSendChatRemoveTemp(),
			scope: "world",
			config: true,
			default: true,
			type: Boolean,
			requiresReload: false,
		});
		
		// Send attack messages to chat
		game.settings.register("pf2e-alchemist-remaster-ducttape", "sendAtkToChat", {
			name: LT.settingSendCraftedItemToChat(),
			hint: LT.settingSendCraftedItemToChatHint(),
			scope: "world",
			config: true,    
			default: false,  
			type: Boolean,   
			requiresReload: false,
		});
		
		// Sized Based Alchemy Settings
		game.settings.register("pf2e-alchemist-remaster-ducttape", "enableSizeBasedAlchemy", {
			name: LT.settingSizebasedAlchemy(),
			hint: LT.settingSizebasedAlchemyHint(),
			scope: "world",
			config: true,
			type: String,
			choices: {
				disabled: LT.disabled(),
				tinyOnly: LT.tinyOnly(),
				allSizes: LT.allSizes()
			},
			default: "tinyOnly",
			onChange: (value) => {
				console.log(`PF2e Alchemist Remaster Duct Tape | Size-based alchemy mode set to: ${value}`);
			},
			requiresReload: false
		});
		
	//	Powerful Alchemy Settings
		console.log("%cPF2e Alchemist Remaster Duct Tape | Initializing Powerful Alchemy settings...","color: aqua; font-weight: bold;");
		game.settings.register("pf2e-alchemist-remaster-ducttape", "enablePowerfulAlchemy", {
			name: LT.settingEnablePowerfulAlchemy(),
			hint: LT.settingEnablePowerfulAlchemyHint(),
			scope: "world",
			config: true,
			type: Boolean,
			default: true,
			onChange: (value) => {
				console.log(`PF2e Alchemist Remaster Duct Tape | Powerful Alchemy enabled: ${value}`);
			},
			requiresReload: true
		});
		
	//	Healing Bomb Settings
		game.settings.register("pf2e-alchemist-remaster-ducttape", "healingBombPC2Errata", {
			name: LT.settingHealingBombPc2Errata(),
			hint: LT.settingHealingBombPc2ErrataHint(),
			scope: "world",
			config: true,
			type: Boolean,
			default: true,
			requiresReload: false,
		});

	//	LevelUp - auto add formulas
		// Add higher level versions of known formulas on level up?
		game.settings.register("pf2e-alchemist-remaster-ducttape", "addFormulasOnLevelUp", {
			name: LT.settingLevelupAddHigher(),
			hint: LT.settingLevelupAddHigherHint(),
			scope: "world",
			config: true,
			type: String,
			choices: {
				disabled: LT.disabled(),
				ask_all: LT.askAll(),
				ask_each: LT.askEach(),
				auto: LT.auto()
			},
			default: "ask_all",
			requiresReload: false,
		});
		
		// How to handle lower level formulas
		game.settings.register("pf2e-alchemist-remaster-ducttape", "handleLowerFormulasOnLevelUp", {
			name: LT.settingLevelupHandleLowerLevel(),
			hint: LT.settingLevelupHandleLowerLevelHint(),
			scope: "world",
			config: true,
			type: String,
			choices: {
				disabled: LT.disabled(),
				add_lower: LT.addLower(),
				remove_lower: LT.removeLower()
			},
			default: "remove_lower",
			requiresReload: false,
		});
		
		// Prompt setting for handleLowerFormulasOnLevelUp
		game.settings.register("pf2e-alchemist-remaster-ducttape", "promptLowerFormulasOnLevelUp", {
			name: LT.settingLevelupPromptRemoveLowerLevel(),
			hint: LT.settingLevelupPromptRemoveLowerLevelHint(),
			scope: "world",
			config: true,
			type: String,
			choices: {
				// auto_lower: LT.auto(),
				ask_all_lower: LT.askAll(),
				ask_each_lower: LT.askEach()
			},
			default: "ask_all_lower",
			requiresReload: false,
		});
		
		// Who is asked by default to add/remove formulas
		game.settings.register("pf2e-alchemist-remaster-ducttape", "addFormulasPermission", {
			name: LT.settingLevelupPermissionLevel(),
			hint: LT.settingLevelupPermissionLevelHint(),
			scope: "world",
			config: true,
			type: String,
			choices: {
				gm_only: LT.gm(),
				actor_owner: LT.owner()
			},
			default: "actor_owner",
			requiresReload: false,
		});
		
		// add list of new formulas learned to chat
		game.settings.register("pf2e-alchemist-remaster-ducttape", "addNewFormulasToChat", {
			name: LT.settingLevelupSendNewRemovedToChat(),
			hint: "",
			scope: "world",
			config: true,
			type: Boolean,
			default: true,
			requiresReload: false,
		});
		
		game.settings.register('pf2e-alchemist-remaster-ducttape', 'compendiums', {
			name: LT.settingCompendiumCheck(),
			hint: LT.settingCompendiumCheckHint(),
			scope: 'world',
			config: false,
			type: Array,
			default: []
		});

		game.settings.registerMenu('pf2e-alchemist-remaster-ducttape', 'addCompendiumsMenu', {
			name: LT.settingAddCompendium(),
			label: LT.settingAddCompendiumLabel(), // This will be the button text
			hint: LT.settingAddCompendiumHint(),
			icon: 'fas fa-plus-circle', // Icon for the button
			type: AddCompendiumsApp, // The FormApplication class to open
			restricted: true // Only accessible by GMs
		});
		
		// Disable addNewFormulasToChat if addFormulasOnLevelUp is set to 'disabled'
		Hooks.on("renderSettingsConfig", (app, html, data) => {
			if (game.release?.generation >= 13) { // If v13
				debugLog(`renderSettingsConfig Foundry v13`);

				const controllerSetting = "pf2e-alchemist-remaster-ducttape.addFormulasOnLevelUp";
				const dependentSettings = [
					"pf2e-alchemist-remaster-ducttape.addNewFormulasToChat",
					"pf2e-alchemist-remaster-ducttape.addFormulasPermission",
					"pf2e-alchemist-remaster-ducttape.handleLowerFormulasOnLevelUp"
				];

				// Get the current value of the controller setting
				const enableAdvancedOptions = game.settings.get("pf2e-alchemist-remaster-ducttape", "addFormulasOnLevelUp");

				// Disable all dependent settings on initial render
				dependentSettings.forEach(setting => {
					const dependentInput = html.querySelector(`input[name="${setting}"], select[name="${setting}"]`);
					if (dependentInput) {
						dependentInput.disabled = (enableAdvancedOptions === 'disabled');
					}
				});

				// Watch for changes to the controller setting
				const controllerSelect = html.querySelector(`select[name="${controllerSetting}"]`);
				if (controllerSelect) {
					controllerSelect.addEventListener("change", (event) => {
						const selectedValue = event.target.value;
						dependentSettings.forEach(setting => {
							const dependentInput = html.querySelector(`input[name="${setting}"], select[name="${setting}"]`);
							if (dependentInput) {
								dependentInput.disabled = (selectedValue === 'disabled');
							}
						});
					});
				}
			} else { // If v12
				debugLog(`renderSettingsConfig Foundry v12`);
				const controllerSetting = "pf2e-alchemist-remaster-ducttape.addFormulasOnLevelUp";
				const dependentSettings = [
					"pf2e-alchemist-remaster-ducttape.addNewFormulasToChat",
					"pf2e-alchemist-remaster-ducttape.addFormulasPermission",
					"pf2e-alchemist-remaster-ducttape.handleLowerFormulasOnLevelUp"
				];
				
				// Get the current value of the controller setting
				const enableAdvancedOptions = game.settings.get("pf2e-alchemist-remaster-ducttape", "addFormulasOnLevelUp");
				
				// Disable both dependent settings on initial render
				dependentSettings.forEach(setting => {
					const dependentInput = html.find(`input[name="${setting}"], select[name="${setting}"]`);
					if (dependentInput.length) {
						dependentInput.prop('disabled', enableAdvancedOptions === 'disabled');
					}
				});
				
				// Watch for changes to the controller setting
				html.find(`select[name="${controllerSetting}"]`).change((event) => {
					const selectedValue = event.target.value;
					
					// Update both dependent settings
					dependentSettings.forEach(setting => {
						const dependentInput = html.find(`input[name="${setting}"], select[name="${setting}"]`);
						if (dependentInput.length) {
							dependentInput.prop('disabled', selectedValue === 'disabled');
						}
					});
				});
			}
		});

	//	Vial Search 
		// Enable Vial Search
		game.settings.register("pf2e-alchemist-remaster-ducttape", "vialSearchReminder", {
			name: LT.settingVialSearchReminder(),
			hint: LT.settingVialSearchReminderHint(),
			scope: "world", 
			config: true,    
			type: Boolean,   
			default: true,  
			requiresReload: true,
		});
		
		// Suppress "Max Vials" Message
		game.settings.register("pf2e-alchemist-remaster-ducttape", "maxVialsMessage", {
			name: LT.settingDisplayMaxVial(),
			hint: LT.settingDisplayMaxVialHint(),
			scope: "world", 
			config: true,    
			type: Boolean,   
			default: false,  
			requiresReload: false,
		});
		
	//	Searchable Formulas
		game.settings.register("pf2e-alchemist-remaster-ducttape", "searchableFormulas", {
			name: LT.settingEnableFormulaSearch(),
			hint: LT.settingEnableFormulaSearchHint(),
			scope: "client", 
			config: true, 
			type: Boolean, 
			default: true, 
			onChange: (value) => {
				console.log(`PF2e Alchemist Remaster Duct Tape | FormulaSearch enabled: ${value}`);
			},
			requiresReload: true
		});
		
	//	Collapse Item Description in chat
		game.settings.register("pf2e-alchemist-remaster-ducttape", "collapseChatDesc", {
			name: LT.settingCollapseItemDescChat(),
			hint: LT.settingCollapseItemDescChatHint(),
			scope: "world", 
			config: true, 
			type: Boolean,
			default: false,
			onChange: (value) => {
				console.log(`PF2e Alchemist Remaster Duct Tape | collapseChatDesc enabled: ${value}`);
			},
			requiresReload: false
		});
		
		// disable our collapse setting if Workbench manages it
		Hooks.on("renderSettingsConfig", (app, html/*, data*/) => {
			const workbenchSettingKey = "xdy-pf2e-workbench.autoCollapseItemChatCardContent";
			const thisSettingKey = "pf2e-alchemist-remaster-ducttape.collapseChatDesc";

			// require Workbench to be active
			if (!game.modules.get("xdy-pf2e-workbench")?.active) return;

			// current WB value
			const wbValue = game.settings.get("xdy-pf2e-workbench", "autoCollapseItemChatCardContent");

			// our checkbox input
			const input = html.querySelector(`input[name="${thisSettingKey}"]`);
			if (!input) return;

			const wrapper = input.closest(".form-group");
			if (!wrapper) return;

			const ensureNote = () => {
				if (wrapper.querySelector(".notes")) return;
				const note = document.createElement("p");
				note.className = "notes";
				note.style.color = "red";
				note.innerText = LT.settingDisabledWorkbench();
				wrapper.appendChild(note);
			};
			const removeNote = () => wrapper.querySelector(".notes")?.remove();

			// set initial state
			if (wbValue === "collapsedDefault" || wbValue === "nonCollapsedDefault") {
				input.disabled = true;
				ensureNote();
			} else {
				input.disabled = false;
				removeNote();
			}

			// react to changes in WB dropdown live
			const wbSelect = html.querySelector(`select[name="${workbenchSettingKey}"]`);
			if (!wbSelect) return;

			wbSelect.addEventListener("change", (ev) => {
				const value = ev.target.value;
				if (value === "collapsedDefault" || value === "nonCollapsedDefault") {
					input.disabled = true;
					ensureNote();
					// keep our setting false when WB owns it
					game.settings.set("pf2e-alchemist-remaster-ducttape", "collapseChatDesc", false);
				} else {
					input.disabled = false;
					removeNote();
				}
			});
		});

	//	Settings section headers
		Hooks.on("renderSettingsConfig", (app, html) => {
			injectSettingsSectionHeaders(html);
		});

	//	Help Button
		game.settings.register("pf2e-alchemist-remaster-ducttape", "showQuickAlchemyHelp", {
			name: LT.settingShowHelp(),
			hint: LT.settingShowHelpHint(),
			scope: "client",
			config: true,
			type: Boolean,
			default: true
		});


	//	Debugging
		// Register debugLevel setting
		game.settings.register("pf2e-alchemist-remaster-ducttape", "debugLevel", {
			name: LT.settingDebugLevel(),
			hint: LT.settingDebugLevelHint(),
			scope: "world",
			config: true,
			type: String,
			choices: {
				"none": LT.settingDebugNone(),
				"error": LT.settingDebugError(),
				"warn": LT.settingDebugWarn(),
				"all": LT.settingDebugAll()
			},
			default: "none", // Default to no logging
			requiresReload: false
		});

		// Log debug status
		const debugLevel = game.settings.get("pf2e-alchemist-remaster-ducttape", "debugLevel");
		console.log(`%cPF2e Alchemist Remaster Duct Tape | Debugging Level: ${debugLevel}`,"color: aqua; font-weight: bold;");
	});

Hooks.once("ready", async () => {

	//	Logging
	debugLog("settings.js | Ready hook triggered.");

	//check folder migration
	try { await checkFolderMigration();} catch (err) {debugLog(3, "settings.js | Compendium folder migration failed:", err?.message ?? err);}
	
	//	Index module item Compendiums
	try {
		const compendiumIds = [
			"pf2e-alchemist-remaster-ducttape.alchemist-duct-tape-items",
			...(game.settings.get("pf2e-alchemist-remaster-ducttape", "compendiums") || [])
		];

		const reindexed = [], missing = [];
		for (const id of compendiumIds) {
			const pack = game.packs.get(id);
			if (!pack) { missing.push(id); continue; }
			// request fields so players get slug in the index
			await pack.getIndex({ fields: ["slug", "system.slug", "name", , "system.traits.value"], reload: true });
			reindexed.push(id);
		}
		debugLog(`settings.js: Reindexed compendiums`, { reindexed, missing });

		// preload
		const preloaded = [], failedPreload = [];
		for (const id of compendiumIds) {
			try {
				const pack = game.packs.get(id);
				if (pack) {
					await pack.getDocuments();
					preloaded.push(id);
				}
			} catch (err) {
				failedPreload.push({ id, reason: err?.message ?? String(err) });
			}
		}
		if (failedPreload.length) debugLog(2, `settings.js: Preloaded compendiums with ${failedPreload.length} failure(s)`, { preloaded, failedPreload });
		else debugLog(`settings.js: Preloaded compendiums`, { preloaded });

	} catch (err) {
		debugLog(3, `settings.js: Error reindexing compendiums: ${err?.message ?? err}`);
	}
	
    //	Adjust collapseChatDesc based on the Workbench setting
    adjustCollapseSettingBasedOnWorkbench();
	
});